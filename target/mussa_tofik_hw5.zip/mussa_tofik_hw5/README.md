**This assignment simulates is a food service application**

It involves preparing and delivering dishes to clients 

## To run the project, please do the following from the root
##  

mvn clean compile
##  

mvn clean package
##  

change directory to target - cd target/
##  

Then do the command below to execute tests
##
java -jar mussa_tofik_hw5-1.0-SNAPSHOT-tests.jar cscie55.hw5.FoodServiceTest 
##  